<?php


If (isset($_POST['id_txt'])){    // se existir o envio do name id_txt será inciado o carrinho

  $id = $_POST ['id_txt'];
  $nome = $_POST ['nome'];
  $quantidade = $_POST ['quantidade'];
  $preco = $_POST ['preco']; 
  $meucarrinho[] = array ('id' => $id,'nome' => $nome,'quantidade' => $quantidade,'preco' => $preco); // array do carrinho
}

session_start();  // iniciar a sessão para inclusão dos itens no carrinho sem buscar no banco de dados

If (isset($_SESSION['carrinho'])){
 $meucarrinho = $_SESSION['carrinho'];  // iniciar a sessão de nome carrinho
If (isset($_POST['id_txt'])){


  $id = $_POST ['id_txt'];
  $nome = $_POST ['nome'];
  $quantidade = $_POST ['quantidade'];
  $preco = $_POST ['preco'];
  $pos = -1;                                              // posição diferente da repetição
    for ($i=0; $i < count($meucarrinho); $i++){          // contagem do índice $i que recebe 0 e acrescenta valores $i++
     if ($id == $meucarrinho[$i]['id']){                 // se o id já existir no carrinho
      $pos = $i;                                         // o valor que está na posição irá ser incluido na mesma posição do índice
 } 

}


  if ($pos <> -1) {                                        // se o índice for diferente d a posição -1 
   $quant = $meucarrinho[$pos] ['quantidade'] + $quantidade; 
   $meucarrinho[$pos] = array ('id' => $id,'nome' => $nome,'quantidade' => $quant,'preco' => $preco); // o valor será mantido e somente a quantidade será alterada
 }
  else {

  $meucarrinho[] = array ('id' => $id,'nome' => $nome,'quantidade' => $quantidade,'preco' => $preco);  // senão o novo valor será acrescentado
}


}
}
 else {                                // else caso a sessão não seja iniciada não será feito nada

  echo '';

}

if (isset($_POST['id2'])) {               // o name será recebido e a quantidade será alterada na exibição final do carrinho
  $indice = $_POST['id2'];
 $quant = $_POST['quantidade2'];
  $meucarrinho[$indice]['quantidade'] = $quant;   // valor novo do índice no array posição quantidade
}

if (isset($_POST['id3'])) {              // o name ira enviar a posição do indice que será excluída
     $indice = $_POST['id3'];             // esse valor será recebido pela variável índice
     unset($meucarrinho[$indice]);         //  a posição do valor será excluída
	 $meucarrinho = array_values($meucarrinho);  // o carrinho se reorganiza 

		  
 }
 
 
 if (isset($meucarrinho)) {                   // se o carrinho existir a sessão carrinho será iniciada 

 $_SESSION['carrinho'] = $meucarrinho;

 }
?>          

<!DOCTYPE HTML>                                                   
<html lang="pt-br">                                              
<head>
<meta @charset="UTF-8"/>                                          
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/> 
<title>Loja Virtual</title>
  <link rel="stylesheet" type="text/css" href="_css/estilo.css"/>   <!-- chamada do estilo css -->
  <link rel="stylesheet" type="text/css" href="_css/form.css"/>
  <link rel="stylesheet" type="text/css" href="css/vendor/normalize.css">
  <link rel="stylesheet" type="text/css" href="dist/gallery.prefixed.css">
  <link rel="stylesheet" type="text/css" href="dist/gallery.theme.css">
  <link rel="shortcut icon" href="_imagens/logopagina.gif">
  
  <style type="text/css">
    section#pesquisa{
	 width: auto;
	 height:1000px;
	}
	
	fieldset#sacola {
    border: 1px solid rgba(0,0,0,.4);
    border-color: rgba(0,0,0,.4);
    margin-top: 5px;
	margin-left: 170px;
	width:800px;
	box-shadow: 1px 1px 3px rgba(0,0,0,.9);
	border-radius: 5px 5px 5px 5px;
}

	table#carrinho {
	width:800px;
	}
	
	#carrinho tr:hover{
	    background-color: #dddddd;
	}
	
	table#titulo_sacola{
	font-size:24px;
	color:#ff0000;
	text-shadow: 1px 1px 3px rgba(0,0,0,.9);
	vertical-align:middle;
	margin-top: 50px;
	margin-left: 170px;
	width:800px;
	height:80px;
	}
	
	td#iMg{
	width:100px;
	}
	
    td#nOme {
	font-size:14px;
	color:#ffffff;
	width:280px;
	text-align:center;
	background-color:#ff0000;
	border-radius: 5px 0px 0px 0px;
	}
	
	td#qUant {
	font-size:14px;
    color:#ffffff;
	background-color:#ff0000;
	width:60px;
	text-align:center;
	}
	
	td#rS {
	font-size:14px;
    color:#ffffff;
	background-color:#ff0000;
	width:50px;
	text-align:center;
	}

	td#add {
	font-size:14px;
    color:#ffffff;
	background-color:#ff0000;
	width:90px;
	text-align:center;
	}

	input#atualizar {
	width:30px;
	text-align:center;
	vertical-align: middle;
	}

	input#imagem_atualizar{
	vertical-align: middle;
	}
	
	#imagem_atualizar input:hover{
	background-color: #dddddd;	
	}

	td#sTot {
	font-size:14px;
	color:#ffffff;
	background-color:#ff0000;
	width:70px;
	text-align:center;
	}

	td#eXcl {
	font-size:14px;
	color:#ffffff;
	background-color:#ff0000;
	width:50px;
	text-align:center;
    border-radius: 0px 5px 0px 0px;
	}

	input#excluir{
	vertical-align: middle;
	}
	
	td#nOme_bd {
	font-size:14px;
	text-align:center;
	}
	
		td#qUant_bd {
	font-size:14px;
	text-align:center;
	}
			td#rS_bd {
	font-size:14px;
	text-align:center;
	}
			td#add_bd {
	font-size:14px;
	text-align:center;
	}
			td#sTot_bd {
	font-size:14px;
	text-align:center;
	}
				td#eXcl_bd {
	font-size:14px;
	text-align:center;
	}
					td#vTot {
	font-size:16px;
	color:#ffffff;
	background-color:#ff0000;
	border-radius: 0px 0px 0px 5px;
	}
						td#vTot1 {
	font-size:16px;
	color:#ffffff;
	background-color:#ff0000;
	}
							td#vTot2 {
	font-size:16px;
	color:#ffffff;
	background-color:#ff0000;
	border-radius: 0px 0px 5px 0px;
	}
								td#vTot3 {
	font-size:16px;
	color:#ffffff;
	background-color:#ff0000;
	}
	
	table#pAg{
	border:1px solid;
	width:820px;
	margin-top:10px;
	margin-left:170px;
	}
	
	td#eSpc{
	width:620px;	
	}
	
  </style>
</head>
<body>

<div id="interface">
 <header id="cabecalho">  <!-- cabecalho  -->
<hgroup> 
<h1><img id="logo" src="_imagens/logofinal.png"><br/>

</h1>
<h3>
<form id="procurar" action= "http://lorussomodas.com.br/pesquisa.php" method="post">
<table>
  <tr>
    <td><input id="Ctext" type="text" name="pesquisar" placeholder="digite aqui sua busca"></td>
    <td><input type="image" id="Cimg" name="Submit" value="OK" src="_imagens/procurar.png" alt="botão enviar"></td>
   </tr>
</table>
</form>
</h3>
<h2>
  <ul id="menu"> 
    <li id=""><span><a href="http://lorussomodas.com.br">&nbsp &nbsp &nbsp &nbsp &nbsp Home</a></span></li>
    <li id=""><span><a href="http://lorussomodas.com.br/produtos.html">Catálogo</a></span></li>
    <li id=""><span><a href="http://lorussomodas.com.br/1.html">Loja Virtual</a></span></li>
    <li id=""><span><a href="http://lorussomodas.com.br/formulario.html#tela1" target="janela">&nbsp &nbsp Novidades</a></span></li>
	<li id=""><span><a href="http://lorussomodas.com.br/formulario.html#tela2" target="janela">Prazos</a></span></li>
	<li id=""><span><a href="http://lorussomodas.com.br/formulario.html#tela3" target="janela">Fale Conosco</a></span></li>
   </ul>

   <iframe name="janela" id="frame-spec_contato" src="http://lorussomodas.com.br/formulario.html" scrolling="no"></iframe>
</h2>
</hgroup>
</header>


 
<section id="pesquisa">

<table id="titulo_sacola">
   <tr>
     <td id="iMg"><img src="_imagens/sacoladecompras.png" border="0" width="80" height="80"></td><td>Sacola de Compras</td>
   </tr>
</table>
<fieldset id="sacola">
<table id="carrinho">
              <tr id="carrinho">
                <td id="nOme">Nome</td>
                <td id="qUant">Quantidade</td>
                <td id="rS">Preço</td>
                <td id="add">Adicionar</td>
                <td id="sTot">Sub Total</td>
                <td id="eXcl">Excluir</td>
             </tr>


<?php
  if(isset($meucarrinho)){   // se a sessão $meucarrinho for iniciada 
     $total = 0;               // valor para total dos produtos
     for($i=0; $i < count($meucarrinho); $i++) {   // índice para inclusão dos itens no carrinho de compras
	 $j = $i+1;  // contador para identificação dos produtos no pagseguro
        IF ($meucarrinho[$i]<>NULL) {   // se o carrinho for diferente de nulo os itens começarão a ser incluídos
	
?>          
   <tr>
                <td id="nOme_bd"><?php echo $meucarrinho[$i]['nome']?></td> <!-- nome do produto  -->
                <td id="qUant_bd"><?php echo $meucarrinho[$i]['quantidade']?></td> <!-- quantidade  -->
                <td id="rS_bd">R$ <?php echo number_format($meucarrinho[$i]['preco'], 2, ',', '.')?></td> <!-- valor  -->
		 		<td id="add_bd"><form action="" method="post" name="atualizar"> <!-- início do formulário  -->
		        <input name="id2" type="hidden" value="<?php echo $i?>"/>  <!-- índice que será enviado, sem exibição na tela, para alterar a quantidade dos produtos   -->
                <input id="atualizar" name="quantidade2" type="text" value="<?php echo $meucarrinho[$i]['quantidade']?>"/> <!-- caixa de texto para incluir número  -->
                <input id="imagem_atualizar" type="image" type="submit" value="Atualizar" src="_imagens/atualizar1.png"/>
                </form>
                </td>
<?php
    $subtotal = $meucarrinho[$i]['preco'] * $meucarrinho[$i]['quantidade'];   // soma do preço e quantidade de produtos por linha do índice
    $total = $total + $subtotal; // valor total de todos os produtos


switch ($j){         // contador do índice $i para identificação da repetição case   

case '1': // o case irá identificar o número do índice de 1 até contador $meucarrinho.
 $id_produto1 = $meucarrinho[$i]['id'];
 $nome_produto1 = $meucarrinho[$i]['nome'];
 $valor_produto1 = $meucarrinho[$i]['preco'];
 $quant_produto1 = $meucarrinho[$i]['quantidade'];
break;

case '2':
 $id_produto2 = $meucarrinho[$i]['id'];
 $nome_produto2 = $meucarrinho[$i]['nome'];
 $valor_produto2 = $meucarrinho[$i]['preco'];
 $quant_produto2 = $meucarrinho[$i]['quantidade'];
break;

case '3':
 $id_produto3 = $meucarrinho[$i]['id'];
 $nome_produto3 = $meucarrinho[$i]['nome'];
 $valor_produto3 = $meucarrinho[$i]['preco'];
 $quant_produto3 = $meucarrinho[$i]['quantidade'];
break;

case '4':
 $id_produto4 = $meucarrinho[$i]['id'];
 $nome_produto4 = $meucarrinho[$i]['nome'];
 $valor_produto4 = $meucarrinho[$i]['preco'];
 $quant_produto4 = $meucarrinho[$i]['quantidade'];
break;

case '5': 
 $id_produto5 = $meucarrinho[$i]['id'];
 $nome_produto5 = $meucarrinho[$i]['nome'];
 $valor_produto5 = $meucarrinho[$i]['preco'];
 $quant_produto5 = $meucarrinho[$j]['quantidade'];
break;

case '6':
 $id_produto6 = $meucarrinho[$i]['id'];
 $nome_produto6 = $meucarrinho[$i]['nome'];
 $valor_produto6 = $meucarrinho[$i]['preco'];
 $quant_produto6 = $meucarrinho[$i]['quantidade'];
break;

case '7':
 $id_produto7 = $meucarrinho[$i]['id'];
 $nome_produto7 = $meucarrinho[$i]['nome'];
 $valor_produto7 = $meucarrinho[$i]['preco'];
 $quant_produto7 = $meucarrinho[$i]['quantidade'];
break;

case '8':
 $id_produto8 = $meucarrinho[$i]['id'];
 $nome_produto8 = $meucarrinho[$i]['nome'];
 $valor_produto8 = $meucarrinho[$i]['preco'];
 $quant_produto8 = $meucarrinho[$i]['quantidade'];
break;

case '9': 
 $id_produto9 = $meucarrinho[$i]['id'];
 $nome_produto9 = $meucarrinho[$i]['nome'];
 $valor_produto9 = $meucarrinho[$i]['preco'];
 $quant_produto9 = $meucarrinho[$j]['quantidade'];
break;

case '10':
 $id_produto10 = $meucarrinho[$i]['id'];
 $nome_produto10 = $meucarrinho[$i]['nome'];
 $valor_produto10 = $meucarrinho[$i]['preco'];
 $quant_produto10 = $meucarrinho[$i]['quantidade'];
break;

case '11':
 $id_produto11 = $meucarrinho[$i]['id'];
 $nome_produto11 = $meucarrinho[$i]['nome'];
 $valor_produto11 = $meucarrinho[$i]['preco'];
 $quant_produto11 = $meucarrinho[$i]['quantidade'];
break;

case '12':
 $id_produto12 = $meucarrinho[$i]['id'];
 $nome_produto12 = $meucarrinho[$i]['nome'];
 $valor_produto12 = $meucarrinho[$i]['preco'];
 $quant_produto12 = $meucarrinho[$i]['quantidade'];
break;

case '13': 
 $id_produto13 = $meucarrinho[$i]['id'];
 $nome_produto13 = $meucarrinho[$i]['nome'];
 $valor_produto13 = $meucarrinho[$i]['preco'];
 $quant_produto13 = $meucarrinho[$j]['quantidade'];
break;

case '14':
 $id_produto14 = $meucarrinho[$i]['id'];
 $nome_produto14 = $meucarrinho[$i]['nome'];
 $valor_produto14 = $meucarrinho[$i]['preco'];
 $quant_produto14 = $meucarrinho[$i]['quantidade'];
break;

case '15': 
 $id_produto15 = $meucarrinho[$i]['id'];
 $nome_produto15 = $meucarrinho[$i]['nome'];
 $valor_produto15 = $meucarrinho[$i]['preco'];
 $quant_produto15 = $meucarrinho[$j]['quantidade'];
break;

case '16':
 $id_produto16 = $meucarrinho[$i]['id'];
 $nome_produto16 = $meucarrinho[$i]['nome'];
 $valor_produto16 = $meucarrinho[$i]['preco'];
 $quant_produto16 = $meucarrinho[$i]['quantidade'];
break;

case '17':
 $id_produto17 = $meucarrinho[$i]['id'];
 $nome_produto17 = $meucarrinho[$i]['nome'];
 $valor_produto17 = $meucarrinho[$i]['preco'];
 $quant_produto17 = $meucarrinho[$i]['quantidade'];
break;

case '18':
 $id_produto18 = $meucarrinho[$i]['id'];
 $nome_produto18 = $meucarrinho[$i]['nome'];
 $valor_produto18 = $meucarrinho[$i]['preco'];
 $quant_produto18 = $meucarrinho[$i]['quantidade'];
break;

case '19': 
 $id_produto19 = $meucarrinho[$i]['id'];
 $nome_produto19 = $meucarrinho[$i]['nome'];
 $valor_produto19 = $meucarrinho[$i]['preco'];
 $quant_produto19 = $meucarrinho[$j]['quantidade'];
break;

case '20':
 $id_produto20 = $meucarrinho[$i]['id'];
 $nome_produto20 = $meucarrinho[$i]['nome'];
 $valor_produto20 = $meucarrinho[$i]['preco'];
 $quant_produto20 = $meucarrinho[$i]['quantidade'];
break;

case '21':
 $id_produto21 = $meucarrinho[$i]['id'];
 $nome_produto21 = $meucarrinho[$i]['nome'];
 $valor_produto21 = $meucarrinho[$i]['preco'];
 $quant_produto21 = $meucarrinho[$i]['quantidade'];
break;

case '22':
 $id_produto22 = $meucarrinho[$i]['id'];
 $nome_produto22 = $meucarrinho[$i]['nome'];
 $valor_produto22 = $meucarrinho[$i]['preco'];
 $quant_produto22 = $meucarrinho[$i]['quantidade'];
break;

case '23': 
 $id_produto23 = $meucarrinho[$i]['id'];
 $nome_produto23 = $meucarrinho[$i]['nome'];
 $valor_produto23 = $meucarrinho[$i]['preco'];
 $quant_produto23 = $meucarrinho[$j]['quantidade'];
break;

case '24':
 $id_produto24 = $meucarrinho[$i]['id'];
 $nome_produto24 = $meucarrinho[$i]['nome'];
 $valor_produto24 = $meucarrinho[$i]['preco'];
 $quant_produto24 = $meucarrinho[$i]['quantidade'];
break;

case '25':
 $id_produto25 = $meucarrinho[$i]['id'];
 $nome_produto25 = $meucarrinho[$i]['nome'];
 $valor_produto25 = $meucarrinho[$i]['preco'];
 $quant_produto25 = $meucarrinho[$i]['quantidade'];
break;

case '26':
 $id_produto26 = $meucarrinho[$i]['id'];
 $nome_produto26 = $meucarrinho[$i]['nome'];
 $valor_produto26 = $meucarrinho[$i]['preco'];
 $quant_produto26 = $meucarrinho[$i]['quantidade'];
break;

case '27': 
 $id_produto27 = $meucarrinho[$i]['id'];
 $nome_produto27 = $meucarrinho[$i]['nome'];
 $valor_produto27 = $meucarrinho[$i]['preco'];
 $quant_produto27 = $meucarrinho[$j]['quantidade'];
break;

case '28':
 $id_produto28 = $meucarrinho[$i]['id'];
 $nome_produto28 = $meucarrinho[$i]['nome'];
 $valor_produto28 = $meucarrinho[$i]['preco'];
 $quant_produto28 = $meucarrinho[$i]['quantidade'];
break;

case '29': 
 $id_produto29 = $meucarrinho[$i]['id'];
 $nome_produto29 = $meucarrinho[$i]['nome'];
 $valor_produto29 = $meucarrinho[$i]['preco'];
 $quant_produto29 = $meucarrinho[$j]['quantidade'];
break;

case '30': 
 $id_produto30 = $meucarrinho[$i]['id'];
 $nome_produto30 = $meucarrinho[$i]['nome'];
 $valor_produto30 = $meucarrinho[$i]['preco'];
 $quant_produto30 = $meucarrinho[$j]['quantidade'];
break;

case '31':
 $id_produto31 = $meucarrinho[$i]['id'];
 $nome_produto31 = $meucarrinho[$i]['nome'];
 $valor_produto31 = $meucarrinho[$i]['preco'];
 $quant_produto31 = $meucarrinho[$i]['quantidade'];
break;

case '32':
 $id_produto32 = $meucarrinho[$i]['id'];
 $nome_produto32 = $meucarrinho[$i]['nome'];
 $valor_produto32 = $meucarrinho[$i]['preco'];
 $quant_produto32 = $meucarrinho[$i]['quantidade'];
break;

case '33':
 $id_produto33 = $meucarrinho[$i]['id'];
 $nome_produto33 = $meucarrinho[$i]['nome'];
 $valor_produto33 = $meucarrinho[$i]['preco'];
 $quant_produto33 = $meucarrinho[$i]['quantidade'];
break;

case '34': 
 $id_produto34 = $meucarrinho[$i]['id'];
 $nome_produto34 = $meucarrinho[$i]['nome'];
 $valor_produto34 = $meucarrinho[$i]['preco'];
 $quant_produto34 = $meucarrinho[$j]['quantidade'];
break;

case '35':
 $id_produto35 = $meucarrinho[$i]['id'];
 $nome_produto35 = $meucarrinho[$i]['nome'];
 $valor_produto35 = $meucarrinho[$i]['preco'];
 $quant_produto35 = $meucarrinho[$i]['quantidade'];
break;

case '36':
 $id_produto36 = $meucarrinho[$i]['id'];
 $nome_produto36 = $meucarrinho[$i]['nome'];
 $valor_produto36 = $meucarrinho[$i]['preco'];
 $quant_produto36 = $meucarrinho[$i]['quantidade'];
break;

case '37':
 $id_produto37 = $meucarrinho[$i]['id'];
 $nome_produto37 = $meucarrinho[$i]['nome'];
 $valor_produto37 = $meucarrinho[$i]['preco'];
 $quant_produto37 = $meucarrinho[$i]['quantidade'];
break;

case '38': 
 $id_produto38 = $meucarrinho[$i]['id'];
 $nome_produto38 = $meucarrinho[$i]['nome'];
 $valor_produto38 = $meucarrinho[$i]['preco'];
 $quant_produto38 = $meucarrinho[$j]['quantidade'];
break;

case '39':
 $id_produto39 = $meucarrinho[$i]['id'];
 $nome_produto39 = $meucarrinho[$i]['nome'];
 $valor_produto39 = $meucarrinho[$i]['preco'];
 $quant_produto39 = $meucarrinho[$i]['quantidade'];
break;

case '40': 
 $id_produto40 = $meucarrinho[$i]['id'];
 $nome_produto40 = $meucarrinho[$i]['nome'];
 $valor_produto40 = $meucarrinho[$i]['preco'];
 $quant_produto40 = $meucarrinho[$j]['quantidade'];
break;

case '41': 
 $id_produto41 = $meucarrinho[$i]['id'];
 $nome_produto41 = $meucarrinho[$i]['nome'];
 $valor_produto41 = $meucarrinho[$i]['preco'];
 $quant_produto41 = $meucarrinho[$j]['quantidade'];
break;

case '42':
 $id_produto42 = $meucarrinho[$i]['id'];
 $nome_produto42 = $meucarrinho[$i]['nome'];
 $valor_produto42 = $meucarrinho[$i]['preco'];
 $quant_produto42 = $meucarrinho[$i]['quantidade'];
break;

case '43':
 $id_produto43 = $meucarrinho[$i]['id'];
 $nome_produto43 = $meucarrinho[$i]['nome'];
 $valor_produto43 = $meucarrinho[$i]['preco'];
 $quant_produto43 = $meucarrinho[$i]['quantidade'];
break;

case '44':
 $id_produto44 = $meucarrinho[$i]['id'];
 $nome_produto44 = $meucarrinho[$i]['nome'];
 $valor_produto44 = $meucarrinho[$i]['preco'];
 $quant_produto44 = $meucarrinho[$i]['quantidade'];
break;

case '45': 
 $id_produto45 = $meucarrinho[$i]['id'];
 $nome_produto45 = $meucarrinho[$i]['nome'];
 $valor_produto45 = $meucarrinho[$i]['preco'];
 $quant_produto45 = $meucarrinho[$j]['quantidade'];
break;

case '46':
 $id_produto46 = $meucarrinho[$i]['id'];
 $nome_produto46 = $meucarrinho[$i]['nome'];
 $valor_produto46 = $meucarrinho[$i]['preco'];
 $quant_produto46 = $meucarrinho[$i]['quantidade'];
break;

case '47':
 $id_produto47 = $meucarrinho[$i]['id'];
 $nome_produto47 = $meucarrinho[$i]['nome'];
 $valor_produto47 = $meucarrinho[$i]['preco'];
 $quant_produto47 = $meucarrinho[$i]['quantidade'];
break;

case '48':
 $id_produto48 = $meucarrinho[$i]['id'];
 $nome_produto48 = $meucarrinho[$i]['nome'];
 $valor_produto48 = $meucarrinho[$i]['preco'];
 $quant_produto48 = $meucarrinho[$i]['quantidade'];
break;

case '49': 
 $id_produto49 = $meucarrinho[$i]['id'];
 $nome_produto49 = $meucarrinho[$i]['nome'];
 $valor_produto49 = $meucarrinho[$i]['preco'];
 $quant_produto49 = $meucarrinho[$j]['quantidade'];
break;

case '50':
 $id_produto50 = $meucarrinho[$i]['id'];
 $nome_produto50 = $meucarrinho[$i]['nome'];
 $valor_produto50 = $meucarrinho[$i]['preco'];
 $quant_produto50 = $meucarrinho[$i]['quantidade'];
break;

default:
echo '';
}
?>
                <td id="sTot_bd">R$ <?php echo number_format($subtotal, 2, ',', '.');?></td> <!-- transformar valor para exibição em decimal -->
                <td id="eXcl_bd"><form action="" method="post">
		        <input name="id3" type="hidden" value="<?php echo $i?>"/>
		        <input id="excluir" type="image" type="submit" value="Excluir" src="_imagens/excluir.png"/>
                </form>
                </td>
            </tr>
<?php
}
}
} 
?>

<tr>
               <tr>
                <td id="vTot"> &nbsp &nbsp Valor Total:</td>
                <td id="vTot1">R$ <?php if(isset($total)) echo number_format($total, 2, ',', '.'); ?></td>
				 <td id="vTot3"> &nbsp  </td>
				  <td id="vTot3">&nbsp </td>
				   <td id="vTot3"> &nbsp </td>
				    <td id="vTot2"> &nbsp </td>
			   </tr>
     </table>
</fieldset>
    <?php
           $itemId1 = 'itemId1';
		   $itemDescription1 = 'itemDescription1';
		   $itemAmount1 = 'itemAmount1';
           $itemQuantity1 = 'itemQuantity1';
           $itemWeight1 = 'itemWeight1';
           $itemId2 = 'itemId2';
           $itemDescription2 = 'itemDescription2';
           $itemAmount2 = 'itemAmount2';
           $itemQuantity2 = 'itemQuantity2';
           $itemWeight2 = 'itemWeight2';
           $itemId3 = 'itemId3';
           $itemDescription3 = 'itemDescription3';	
           $itemAmount3 = 'itemAmount3';	
           $itemQuantity3 = 'itemQuantity3';
           $itemWeight3 = 'itemWeight3';		   
           $itemId4 = 'itemId4';
           $itemDescription4 = 'itemDescription4';
           $itemAmount4 = 'itemAmount4';
           $itemQuantity4 = 'itemQuantity4';
           $itemWeight4 = 'itemWeight4';
		   $itemId5 = 'itemId5';
	       $itemDescription5 = 'itemDescription5';
	       $itemAmount5 = 'itemAmount5';
           $itemQuantity5 = 'itemQuantity5';
           $itemWeight5 = 'itemWeight5';
           $itemId6 = 'itemId6';
           $itemDescription6 = 'itemDescription6';
           $itemAmount6 = 'itemAmount6';
           $itemQuantity6 = 'itemQuantity6';
           $itemWeight6 = 'itemWeight6';
           $itemId7 = 'itemId7';
           $itemDescription7 = 'itemDescription7';	
           $itemAmount7 = 'itemAmount7';	
           $itemQuantity7 = 'itemQuantity7';
           $itemWeight7 = 'itemWeight7';		   
           $itemId8 = 'itemId8';
           $itemDescription8 = 'itemDescription8';
           $itemAmount8 = 'itemAmount8';
           $itemQuantity8 = 'itemQuantity8';
           $itemWeight8 = 'itemWeight8';
		   $itemId9 = 'itemId9';
		   $itemDescription9 = 'itemDescription9';
		   $itemAmount9 = 'itemAmount9';
           $itemQuantity9 = 'itemQuantity9';
           $itemWeight9 = 'itemWeight9';
           $itemId10 = 'itemId10';
           $itemDescription10 = 'itemDescription10';
           $itemAmount10 = 'itemAmount10';
           $itemQuantity10 = 'itemQuantity10';
           $itemWeight10 = 'itemWeight10';
           $itemId11 = 'itemId11';
           $itemDescription11 = 'itemDescription11';	
           $itemAmount11 = 'itemAmount11';	
           $itemQuantity11 = 'itemQuantity11';
           $itemWeight11 = 'itemWeight11';		   
           $itemId12 = 'itemId12';
           $itemDescription12 = 'itemDescription12';
           $itemAmount12 = 'itemAmount12';
           $itemQuantity12 = 'itemQuantity12';
           $itemWeight12 = 'itemWeight12';
		   $itemId13 = 'itemId13';
	       $itemDescription13 = 'itemDescription13';
	       $itemAmount13 = 'itemAmount13';
           $itemQuantity13 = 'itemQuantity13';
           $itemWeight13 = 'itemWeight13';
           $itemId14 = 'itemId14';
           $itemDescription14 = 'itemDescription14';
           $itemAmount14 = 'itemAmount14';
           $itemQuantity14 = 'itemQuantity14';
           $itemWeight14 = 'itemWeight14';
           $itemId15 = 'itemId15';
           $itemDescription15 = 'itemDescription15';	
           $itemAmount15 = 'itemAmount15';	
           $itemQuantity15 = 'itemQuantity15';
           $itemWeight15 = 'itemWeight15';		   
           $itemId16 = 'itemId16';
           $itemDescription16 = 'itemDescription16';
           $itemAmount16 = 'itemAmount16';
           $itemQuantity16 = 'itemQuantity16';
           $itemWeight16 = 'itemWeight16';
           $itemId17 = 'itemId17';
		   $itemDescription17 = 'itemDescription17';
		   $itemAmount17 = 'itemAmount17';
           $itemQuantity17 = 'itemQuantity17';
           $itemWeight17 = 'itemWeight17';
           $itemId18 = 'itemId18';
           $itemDescription18 = 'itemDescription18';
           $itemAmount18 = 'itemAmount18';
           $itemQuantity18 = 'itemQuantity18';
           $itemWeight18 = 'itemWeight18';
           $itemId19 = 'itemId19';
           $itemDescription19 = 'itemDescription19';	
           $itemAmount19 = 'itemAmount19';	
           $itemQuantity19 = 'itemQuantity19';
           $itemWeight19 = 'itemWeight19';		   
           $itemId20 = 'itemId20';
           $itemDescription20 = 'itemDescription20';
           $itemAmount20 = 'itemAmount20';
           $itemQuantity20 = 'itemQuantity20';
           $itemWeight20 = 'itemWeight20';
		   $itemId21 = 'itemId21';
	       $itemDescription21 = 'itemDescription21';
	       $itemAmount21 = 'itemAmount21';
           $itemQuantity21 = 'itemQuantity21';
           $itemWeight21 = 'itemWeight21';
           $itemId22 = 'itemId22';
           $itemDescription22 = 'itemDescription22';
           $itemAmount22 = 'itemAmount22';
           $itemQuantity22 = 'itemQuantity22';
           $itemWeight22 = 'itemWeight22';
           $itemId23 = 'itemId23';
           $itemDescription23 = 'itemDescription23';	
           $itemAmount23 = 'itemAmount23';	
           $itemQuantity23 = 'itemQuantity23';
           $itemWeight23 = 'itemWeight23';		   
           $itemId24 = 'itemId24';
           $itemDescription24 = 'itemDescription24';
           $itemAmount24 = 'itemAmount24';
           $itemQuantity24 = 'itemQuantity24';
           $itemWeight24 = 'itemWeight24';
		   $itemId25 = 'itemId25';
		   $itemDescription25 = 'itemDescription25';
		   $itemAmount25 = 'itemAmount25';
           $itemQuantity25 = 'itemQuantity25';
           $itemWeight25 = 'itemWeight25';
           $itemId26 = 'itemId26';
           $itemDescription26 = 'itemDescription26';
           $itemAmount26 = 'itemAmount26';
           $itemQuantity26 = 'itemQuantity26';
           $itemWeight26 = 'itemWeight26';
           $itemId27 = 'itemId27';
           $itemDescription27 = 'itemDescription27';	
           $itemAmount27 = 'itemAmount27';	
           $itemQuantity27 = 'itemQuantity27';
           $itemWeight27 = 'itemWeight27';		   
           $itemId28 = 'itemId28';
           $itemDescription28 = 'itemDescription28';
           $itemAmount28 = 'itemAmount28';
           $itemQuantity28 = 'itemQuantity28';
           $itemWeight28 = 'itemWeight28';
		   $itemId29 = 'itemId29';
	       $itemDescription29 = 'itemDescription29';
	       $itemAmount29 = 'itemAmount29';
           $itemQuantity29 = 'itemQuantity29';
           $itemWeight29 = 'itemWeight29';
           $itemId30 = 'itemId30';
           $itemDescription30 = 'itemDescription30';
           $itemAmount30 = 'itemAmount30';
           $itemQuantity30 = 'itemQuantity30';
           $itemWeight30 = 'itemWeight30';
           $itemId31 = 'itemId31';
           $itemDescription31 = 'itemDescription31';	
           $itemAmount31 = 'itemAmount31';	
           $itemQuantity31 = 'itemQuantity31';
           $itemWeight31 = 'itemWeight31';		   
           $itemId32 = 'itemId32';
           $itemDescription32 = 'itemDescription32';
           $itemAmount32 = 'itemAmount32';
           $itemQuantity32 = 'itemQuantity32';
           $itemWeight32 = 'itemWeight32';
           $itemId33 = 'itemId33';
		   $itemDescription33 = 'itemDescription33';
		   $itemAmount33 = 'itemAmount33';
           $itemQuantity33 = 'itemQuantity33';
           $itemWeight33 = 'itemWeight33';
           $itemId34 = 'itemId34';
           $itemDescription34 = 'itemDescription34';
           $itemAmount34 = 'itemAmount34';
           $itemQuantity34 = 'itemQuantity34';
           $itemWeight34 = 'itemWeight34';
           $itemId35 = 'itemId35';
           $itemDescription35 = 'itemDescription35';	
           $itemAmount35 = 'itemAmount35';	
           $itemQuantity35 = 'itemQuantity35';
           $itemWeight35 = 'itemWeight35';		   
           $itemId36 = 'itemId36';
           $itemDescription36 = 'itemDescription36';
           $itemAmount36 = 'itemAmount36';
           $itemQuantity36 = 'itemQuantity36';
           $itemWeight36 = 'itemWeight36';
		   $itemId37 = 'itemId37';
	       $itemDescription37 = 'itemDescription37';
	       $itemAmount37 = 'itemAmount37';
           $itemQuantity37 = 'itemQuantity37';
           $itemWeight37 = 'itemWeight37';
           $itemId38 = 'itemId38';
           $itemDescription38 = 'itemDescription38';
           $itemAmount38 = 'itemAmount38';
           $itemQuantity38 = 'itemQuantity38';
           $itemWeight38 = 'itemWeight38';
           $itemId39 = 'itemId39';
           $itemDescription39 = 'itemDescription39';	
           $itemAmount39 = 'itemAmount39';	
           $itemQuantity39 = 'itemQuantity39';
           $itemWeight39 = 'itemWeight39';		   
           $itemId40 = 'itemId40';
           $itemDescription40 = 'itemDescription40';
           $itemAmount40 = 'itemAmount40';
           $itemQuantity40 = 'itemQuantity40';
           $itemWeight40 = 'itemWeight40';
		   $itemId41 = 'itemId41';
		   $itemDescription41 = 'itemDescription41';
		   $itemAmount41 = 'itemAmount41';
           $itemQuantity41 = 'itemQuantity41';
           $itemWeight41 = 'itemWeight41';
           $itemId42 = 'itemId42';
           $itemDescription42 = 'itemDescription42';
           $itemAmount42 = 'itemAmount42';
           $itemQuantity42 = 'itemQuantity42';
           $itemWeight42 = 'itemWeight42';
           $itemId43 = 'itemId43';
           $itemDescription43 = 'itemDescription43';	
           $itemAmount43 = 'itemAmount43';	
           $itemQuantity43 = 'itemQuantity43';
           $itemWeight43 = 'itemWeight43';		   
           $itemId44 = 'itemId44';
           $itemDescription44 = 'itemDescription44';
           $itemAmount44 = 'itemAmount44';
           $itemQuantity44 = 'itemQuantity44';
           $itemWeight44 = 'itemWeight44';
		   $itemId45 = 'itemId45';
	       $itemDescription45 = 'itemDescription45';
	       $itemAmount45 = 'itemAmount45';
           $itemQuantity45 = 'itemQuantity45';
           $itemWeight45 = 'itemWeight45';
           $itemId46 = 'itemId46';
           $itemDescription46 = 'itemDescription46';
           $itemAmount46 = 'itemAmount46';
           $itemQuantity46 = 'itemQuantity46';
           $itemWeight46 = 'itemWeight46';
           $itemId47 = 'itemId47';
           $itemDescription47 = 'itemDescription47';	
           $itemAmount47 = 'itemAmount47';	
           $itemQuantity47 = 'itemQuantity47';
           $itemWeight47 = 'itemWeight47';		   
           $itemId48 = 'itemId48';
           $itemDescription48 = 'itemDescription48';
           $itemAmount48 = 'itemAmount48';
           $itemQuantity48 = 'itemQuantity48';
           $itemWeight48 = 'itemWeight48';
           $itemId49 = 'itemId49';
           $itemDescription49 = 'itemDescription49';	
           $itemAmount49 = 'itemAmount49';	
           $itemQuantity49 = 'itemQuantity49';
           $itemWeight49 = 'itemWeight49';		   
           $itemId50 = 'itemId50';
           $itemDescription50 = 'itemDescription50';
           $itemAmount50 = 'itemAmount50';
           $itemQuantity50 = 'itemQuantity50';
           $itemWeight50 = 'itemWeight50';


           
     ?>
	 
<form method="post" target="pagseguro"  action="https://pagseguro.uol.com.br/v2/checkout/payment.html">
       <!-- Campos obrigatórios -->
    <input name="receiverEmail" value="fabiojosesilva@ig.com.br" type="hidden">
    <input name="currency" value="BRL" type="hidden">
	
    <input type="hidden" name="<?php echo $itemId1; ?>" value="<?php echo $id_produto1;?>">
    <input type="hidden" name="<?php echo $itemDescription1; ?>" value="<?php echo $nome_produto1;?>">
    <input type="hidden" name="<?php echo $itemAmount1; ?>" value="<?php echo $valor_produto1;?>">
    <input type="hidden" name="<?php echo $itemQuantity1; ?>" value="<?php echo $quant_produto1;?>">
    <input type="hidden" name="<?php echo $itemWeight1; ?>" value="1000">

    <input type="hidden" name="<?php echo $itemId2;?>" value="<?php echo $id_produto2;?>">
    <input type="hidden" name="<?php echo $itemDescription2;?>" value="<?php echo $nome_produto2;?>">
    <input type="hidden" name="<?php echo $itemAmount2;?>" value="<?php echo $valor_produto2;?>">
    <input type="hidden" name="<?php echo $itemQuantity2;?>" value="<?php echo $quant_produto2;?>">
    <input type="hidden" name="<?php echo $itemWeight2;?>" value="1000">

    <input type="hidden" name="<?php echo $itemId3; ?>" value="<?php echo $id_produto3;?>">
    <input type="hidden" name="<?php echo $itemDescription3; ?>" value="<?php echo $nome_produto3;?>">
    <input type="hidden" name="<?php echo $itemAmount3;?>" value="<?php echo $valor_produto3;?>">
    <input type="hidden" name="<?php echo $itemQuantity3;?>" value="<?php echo $quant_produto3;?>">
    <input type="hidden" name="<?php echo $itemWeight3;?>" value="1000">
	
	<input type="hidden" name="<?php echo $itemId4; ?>" value="<?php echo $id_produto4;?>">
    <input type="hidden" name="<?php echo $itemDescription4; ?>" value="<?php echo $nome_produto4;?>">
    <input type="hidden" name="<?php echo $itemAmount4;?>" value="<?php echo $valor_produto4;?>">
    <input type="hidden" name="<?php echo $itemQuantity4;?>" value="<?php echo $quant_produto4;?>">
    <input type="hidden" name="<?php echo $itemWeight4;?>" value="1000">
	
	<input type="hidden" name="<?php echo $itemId5; ?>" value="<?php echo $id_produto5;?>">
    <input type="hidden" name="<?php echo $itemDescription5; ?>" value="<?php echo $nome_produto5;?>">
    <input type="hidden" name="<?php echo $itemAmount5; ?>" value="<?php echo $valor_produto5;?>">
    <input type="hidden" name="<?php echo $itemQuantity5; ?>" value="<?php echo $quant_produto5;?>">
    <input type="hidden" name="<?php echo $itemWeight5; ?>" value="1000">

    <input type="hidden" name="<?php echo $itemId6;?>" value="<?php echo $id_produto6;?>">
    <input type="hidden" name="<?php echo $itemDescription6;?>" value="<?php echo $nome_produto6;?>">
    <input type="hidden" name="<?php echo $itemAmount6;?>" value="<?php echo $valor_produto6;?>">
    <input type="hidden" name="<?php echo $itemQuantity6;?>" value="<?php echo $quant_produto6;?>">
    <input type="hidden" name="<?php echo $itemWeight6;?>" value="1000">

    <input type="hidden" name="<?php echo $itemId7; ?>" value="<?php echo $id_produto7;?>">
    <input type="hidden" name="<?php echo $itemDescription7; ?>" value="<?php echo $nome_produto7;?>">
    <input type="hidden" name="<?php echo $itemAmount7;?>" value="<?php echo $valor_produto7;?>">
    <input type="hidden" name="<?php echo $itemQuantity7;?>" value="<?php echo $quant_produto7;?>">
    <input type="hidden" name="<?php echo $itemWeight7;?>" value="1000">
	
	<input type="hidden" name="<?php echo $itemId8; ?>" value="<?php echo $id_produto8;?>">
    <input type="hidden" name="<?php echo $itemDescription8; ?>" value="<?php echo $nome_produto8;?>">
    <input type="hidden" name="<?php echo $itemAmount8;?>" value="<?php echo $valor_produto8;?>">
    <input type="hidden" name="<?php echo $itemQuantity8;?>" value="<?php echo $quant_produto8;?>">
    <input type="hidden" name="<?php echo $itemWeight8;?>" value="1000">
	
	<input type="hidden" name="<?php echo $itemId9; ?>" value="<?php echo $id_produto9;?>">
    <input type="hidden" name="<?php echo $itemDescription9; ?>" value="<?php echo $nome_produto9;?>">
    <input type="hidden" name="<?php echo $itemAmount9; ?>" value="<?php echo $valor_produto9;?>">
    <input type="hidden" name="<?php echo $itemQuantity9; ?>" value="<?php echo $quant_produto9;?>">
    <input type="hidden" name="<?php echo $itemWeight9; ?>" value="1000">

    <input type="hidden" name="<?php echo $itemId10;?>" value="<?php echo $id_produto10;?>">
    <input type="hidden" name="<?php echo $itemDescription10;?>" value="<?php echo $nome_produto10;?>">
    <input type="hidden" name="<?php echo $itemAmount10;?>" value="<?php echo $valor_produto10;?>">
    <input type="hidden" name="<?php echo $itemQuantity10;?>" value="<?php echo $quant_produto10;?>">
    <input type="hidden" name="<?php echo $itemWeight10;?>" value="1000">

    <input type="hidden" name="<?php echo $itemId11; ?>" value="<?php echo $id_produto11;?>">
    <input type="hidden" name="<?php echo $itemDescription11; ?>" value="<?php echo $nome_produto11;?>">
    <input type="hidden" name="<?php echo $itemAmount11;?>" value="<?php echo $valor_produto11;?>">
    <input type="hidden" name="<?php echo $itemQuantity11;?>" value="<?php echo $quant_produto11;?>">
    <input type="hidden" name="<?php echo $itemWeight11;?>" value="1000">
	
	<input type="hidden" name="<?php echo $itemId12; ?>" value="<?php echo $id_produto12;?>">
    <input type="hidden" name="<?php echo $itemDescription12; ?>" value="<?php echo $nome_produto12;?>">
    <input type="hidden" name="<?php echo $itemAmount12;?>" value="<?php echo $valor_produto12;?>">
    <input type="hidden" name="<?php echo $itemQuantity12;?>" value="<?php echo $quant_produto12;?>">
    <input type="hidden" name="<?php echo $itemWeight12;?>" value="1000">
	
	<input type="hidden" name="<?php echo $itemId13; ?>" value="<?php echo $id_produto13;?>">
    <input type="hidden" name="<?php echo $itemDescription13; ?>" value="<?php echo $nome_produto13;?>">
    <input type="hidden" name="<?php echo $itemAmount13; ?>" value="<?php echo $valor_produto13;?>">
    <input type="hidden" name="<?php echo $itemQuantity13; ?>" value="<?php echo $quant_produto13;?>">
    <input type="hidden" name="<?php echo $itemWeight13; ?>" value="1000">

    <input type="hidden" name="<?php echo $itemId14;?>" value="<?php echo $id_produto14;?>">
    <input type="hidden" name="<?php echo $itemDescription14;?>" value="<?php echo $nome_produto14;?>">
    <input type="hidden" name="<?php echo $itemAmount14;?>" value="<?php echo $valor_produto14;?>">
    <input type="hidden" name="<?php echo $itemQuantity14;?>" value="<?php echo $quant_produto14;?>">
    <input type="hidden" name="<?php echo $itemWeight14;?>" value="1000">

    <input type="hidden" name="<?php echo $itemId15; ?>" value="<?php echo $id_produto15;?>">
    <input type="hidden" name="<?php echo $itemDescription15; ?>" value="<?php echo $nome_produto15;?>">
    <input type="hidden" name="<?php echo $itemAmount15;?>" value="<?php echo $valor_produto15;?>">
    <input type="hidden" name="<?php echo $itemQuantity15;?>" value="<?php echo $quant_produto15;?>">
    <input type="hidden" name="<?php echo $itemWeight15;?>" value="1000">
	
	<input type="hidden" name="<?php echo $itemId16; ?>" value="<?php echo $id_produto16;?>">
    <input type="hidden" name="<?php echo $itemDescription16; ?>" value="<?php echo $nome_produto16;?>">
    <input type="hidden" name="<?php echo $itemAmount16;?>" value="<?php echo $valor_produto16;?>">
    <input type="hidden" name="<?php echo $itemQuantity16;?>" value="<?php echo $quant_produto16;?>">
    <input type="hidden" name="<?php echo $itemWeight16;?>" value="1000">
	
    <input type="hidden" name="<?php echo $itemId17; ?>" value="<?php echo $id_produto17;?>">
    <input type="hidden" name="<?php echo $itemDescription17; ?>" value="<?php echo $nome_produto17;?>">
    <input type="hidden" name="<?php echo $itemAmount17; ?>" value="<?php echo $valor_produto17;?>">
    <input type="hidden" name="<?php echo $itemQuantity17; ?>" value="<?php echo $quant_produto17;?>">
    <input type="hidden" name="<?php echo $itemWeight17; ?>" value="1000">

    <input type="hidden" name="<?php echo $itemId18;?>" value="<?php echo $id_produto18;?>">
    <input type="hidden" name="<?php echo $itemDescription18;?>" value="<?php echo $nome_produto18;?>">
    <input type="hidden" name="<?php echo $itemAmount18;?>" value="<?php echo $valor_produto18;?>">
    <input type="hidden" name="<?php echo $itemQuantity18;?>" value="<?php echo $quant_produto18;?>">
    <input type="hidden" name="<?php echo $itemWeight18;?>" value="1000">

    <input type="hidden" name="<?php echo $itemId19; ?>" value="<?php echo $id_produto19;?>">
    <input type="hidden" name="<?php echo $itemDescription19; ?>" value="<?php echo $nome_produto19;?>">
    <input type="hidden" name="<?php echo $itemAmount19;?>" value="<?php echo $valor_produto19;?>">
    <input type="hidden" name="<?php echo $itemQuantity19;?>" value="<?php echo $quant_produto19;?>">
    <input type="hidden" name="<?php echo $itemWeight19;?>" value="1000">
	
	<input type="hidden" name="<?php echo $itemId20; ?>" value="<?php echo $id_produto20;?>">
    <input type="hidden" name="<?php echo $itemDescription20; ?>" value="<?php echo $nome_produto20;?>">
    <input type="hidden" name="<?php echo $itemAmount20;?>" value="<?php echo $valor_produto20;?>">
    <input type="hidden" name="<?php echo $itemQuantity20;?>" value="<?php echo $quant_produto20;?>">
    <input type="hidden" name="<?php echo $itemWeight20;?>" value="1000">
	
	<input type="hidden" name="<?php echo $itemId21; ?>" value="<?php echo $id_produto21;?>">
    <input type="hidden" name="<?php echo $itemDescription21; ?>" value="<?php echo $nome_produto21;?>">
    <input type="hidden" name="<?php echo $itemAmount21; ?>" value="<?php echo $valor_produto21;?>">
    <input type="hidden" name="<?php echo $itemQuantity21; ?>" value="<?php echo $quant_produto21;?>">
    <input type="hidden" name="<?php echo $itemWeight21; ?>" value="1000">

    <input type="hidden" name="<?php echo $itemId22;?>" value="<?php echo $id_produto22;?>">
    <input type="hidden" name="<?php echo $itemDescription22;?>" value="<?php echo $nome_produto22;?>">
    <input type="hidden" name="<?php echo $itemAmount22;?>" value="<?php echo $valor_produto22;?>">
    <input type="hidden" name="<?php echo $itemQuantity22;?>" value="<?php echo $quant_produto22;?>">
    <input type="hidden" name="<?php echo $itemWeight22;?>" value="1000">

    <input type="hidden" name="<?php echo $itemId23; ?>" value="<?php echo $id_produto23;?>">
    <input type="hidden" name="<?php echo $itemDescription23; ?>" value="<?php echo $nome_produto23;?>">
    <input type="hidden" name="<?php echo $itemAmount23;?>" value="<?php echo $valor_produto23;?>">
    <input type="hidden" name="<?php echo $itemQuantity23;?>" value="<?php echo $quant_produto23;?>">
    <input type="hidden" name="<?php echo $itemWeight23;?>" value="1000">
	
	<input type="hidden" name="<?php echo $itemId24; ?>" value="<?php echo $id_produto24;?>">
    <input type="hidden" name="<?php echo $itemDescription24; ?>" value="<?php echo $nome_produto24;?>">
    <input type="hidden" name="<?php echo $itemAmount24;?>" value="<?php echo $valor_produto24;?>">
    <input type="hidden" name="<?php echo $itemQuantity24;?>" value="<?php echo $quant_produto24;?>">
    <input type="hidden" name="<?php echo $itemWeight24;?>" value="1000">
	
	<input type="hidden" name="<?php echo $itemId25; ?>" value="<?php echo $id_produto25;?>">
    <input type="hidden" name="<?php echo $itemDescription25; ?>" value="<?php echo $nome_produto25;?>">
    <input type="hidden" name="<?php echo $itemAmount25; ?>" value="<?php echo $valor_produto25;?>">
    <input type="hidden" name="<?php echo $itemQuantity25; ?>" value="<?php echo $quant_produto25;?>">
    <input type="hidden" name="<?php echo $itemWeight25; ?>" value="1000">

    <input type="hidden" name="<?php echo $itemId26;?>" value="<?php echo $id_produto26;?>">
    <input type="hidden" name="<?php echo $itemDescription26;?>" value="<?php echo $nome_produto26;?>">
    <input type="hidden" name="<?php echo $itemAmount26;?>" value="<?php echo $valor_produto26;?>">
    <input type="hidden" name="<?php echo $itemQuantity26;?>" value="<?php echo $quant_produto26;?>">
    <input type="hidden" name="<?php echo $itemWeight26;?>" value="1000">

    <input type="hidden" name="<?php echo $itemId27; ?>" value="<?php echo $id_produto27;?>">
    <input type="hidden" name="<?php echo $itemDescription27; ?>" value="<?php echo $nome_produto27;?>">
    <input type="hidden" name="<?php echo $itemAmount27;?>" value="<?php echo $valor_produto27;?>">
    <input type="hidden" name="<?php echo $itemQuantity27;?>" value="<?php echo $quant_produto27;?>">
    <input type="hidden" name="<?php echo $itemWeight27;?>" value="1000">
	
	<input type="hidden" name="<?php echo $itemId28; ?>" value="<?php echo $id_produto28;?>">
    <input type="hidden" name="<?php echo $itemDescription28; ?>" value="<?php echo $nome_produto28;?>">
    <input type="hidden" name="<?php echo $itemAmount28;?>" value="<?php echo $valor_produto28;?>">
    <input type="hidden" name="<?php echo $itemQuantity28;?>" value="<?php echo $quant_produto28;?>">
    <input type="hidden" name="<?php echo $itemWeight28;?>" value="1000">
	
	<input type="hidden" name="<?php echo $itemId29; ?>" value="<?php echo $id_produto29;?>">
    <input type="hidden" name="<?php echo $itemDescription29; ?>" value="<?php echo $nome_produto29;?>">
    <input type="hidden" name="<?php echo $itemAmount29; ?>" value="<?php echo $valor_produto29;?>">
    <input type="hidden" name="<?php echo $itemQuantity29; ?>" value="<?php echo $quant_produto29;?>">
    <input type="hidden" name="<?php echo $itemWeight29; ?>" value="1000">

    <input type="hidden" name="<?php echo $itemId30;?>" value="<?php echo $id_produto30;?>">
    <input type="hidden" name="<?php echo $itemDescription30;?>" value="<?php echo $nome_produto30;?>">
    <input type="hidden" name="<?php echo $itemAmount30;?>" value="<?php echo $valor_produto30;?>">
    <input type="hidden" name="<?php echo $itemQuantity30;?>" value="<?php echo $quant_produto30;?>">
    <input type="hidden" name="<?php echo $itemWeight30;?>" value="1000">

    <input type="hidden" name="<?php echo $itemId31; ?>" value="<?php echo $id_produto31;?>">
    <input type="hidden" name="<?php echo $itemDescription31; ?>" value="<?php echo $nome_produto31;?>">
    <input type="hidden" name="<?php echo $itemAmount31;?>" value="<?php echo $valor_produto31;?>">
    <input type="hidden" name="<?php echo $itemQuantity31;?>" value="<?php echo $quant_produto31;?>">
    <input type="hidden" name="<?php echo $itemWeight31;?>" value="1000">
	
	<input type="hidden" name="<?php echo $itemId32; ?>" value="<?php echo $id_produto32;?>">
    <input type="hidden" name="<?php echo $itemDescription32; ?>" value="<?php echo $nome_produto32;?>">
    <input type="hidden" name="<?php echo $itemAmount32;?>" value="<?php echo $valor_produto32;?>">
    <input type="hidden" name="<?php echo $itemQuantity32;?>" value="<?php echo $quant_produto32;?>">
    <input type="hidden" name="<?php echo $itemWeight32;?>" value="1000">

    <input type="hidden" name="<?php echo $itemId33; ?>" value="<?php echo $id_produto49;?>">
    <input type="hidden" name="<?php echo $itemDescription33; ?>" value="<?php echo $nome_produto49;?>">
    <input type="hidden" name="<?php echo $itemAmount33; ?>" value="<?php echo $valor_produto49;?>">
    <input type="hidden" name="<?php echo $itemQuantity33; ?>" value="<?php echo $quant_produto49;?>">
    <input type="hidden" name="<?php echo $itemWeight33; ?>" value="1000">

    <input type="hidden" name="<?php echo $itemId34;?>" value="<?php echo $id_produto50;?>">
    <input type="hidden" name="<?php echo $itemDescription34;?>" value="<?php echo $nome_produto50;?>">
    <input type="hidden" name="<?php echo $itemAmount34;?>" value="<?php echo $valor_produto50;?>">
    <input type="hidden" name="<?php echo $itemQuantity34;?>" value="<?php echo $quant_produto50;?>">
    <input type="hidden" name="<?php echo $itemWeight34;?>" value="1000">

    <input type="hidden" name="<?php echo $itemId35; ?>" value="<?php echo $id_produto35;?>">
    <input type="hidden" name="<?php echo $itemDescription35; ?>" value="<?php echo $nome_produto35;?>">
    <input type="hidden" name="<?php echo $itemAmount35;?>" value="<?php echo $valor_produto35;?>">
    <input type="hidden" name="<?php echo $itemQuantity35;?>" value="<?php echo $quant_produto35;?>">
    <input type="hidden" name="<?php echo $itemWeight35;?>" value="1000">
	
	<input type="hidden" name="<?php echo $itemId36; ?>" value="<?php echo $id_produto36;?>">
    <input type="hidden" name="<?php echo $itemDescription36; ?>" value="<?php echo $nome_produto36;?>">
    <input type="hidden" name="<?php echo $itemAmount36;?>" value="<?php echo $valor_produto36;?>">
    <input type="hidden" name="<?php echo $itemQuantity36;?>" value="<?php echo $quant_produto36;?>">
    <input type="hidden" name="<?php echo $itemWeight36;?>" value="1000">
	
	<input type="hidden" name="<?php echo $itemId37; ?>" value="<?php echo $id_produto37;?>">
    <input type="hidden" name="<?php echo $itemDescription37; ?>" value="<?php echo $nome_produto37;?>">
    <input type="hidden" name="<?php echo $itemAmount37; ?>" value="<?php echo $valor_produto37;?>">
    <input type="hidden" name="<?php echo $itemQuantity37; ?>" value="<?php echo $quant_produto37;?>">
    <input type="hidden" name="<?php echo $itemWeight37; ?>" value="1000">

    <input type="hidden" name="<?php echo $itemId38;?>" value="<?php echo $id_produto38;?>">
    <input type="hidden" name="<?php echo $itemDescription38;?>" value="<?php echo $nome_produto38;?>">
    <input type="hidden" name="<?php echo $itemAmount38;?>" value="<?php echo $valor_produto38;?>">
    <input type="hidden" name="<?php echo $itemQuantity38;?>" value="<?php echo $quant_produto38;?>">
    <input type="hidden" name="<?php echo $itemWeight38;?>" value="1000">

    <input type="hidden" name="<?php echo $itemId39; ?>" value="<?php echo $id_produto39;?>">
    <input type="hidden" name="<?php echo $itemDescription39; ?>" value="<?php echo $nome_produto39;?>">
    <input type="hidden" name="<?php echo $itemAmount39;?>" value="<?php echo $valor_produto39;?>">
    <input type="hidden" name="<?php echo $itemQuantity39;?>" value="<?php echo $quant_produto39;?>">
    <input type="hidden" name="<?php echo $itemWeight39;?>" value="1000">
	
	<input type="hidden" name="<?php echo $itemId40; ?>" value="<?php echo $id_produto40;?>">
    <input type="hidden" name="<?php echo $itemDescription40; ?>" value="<?php echo $nome_produto40;?>">
    <input type="hidden" name="<?php echo $itemAmount40;?>" value="<?php echo $valor_produto40;?>">
    <input type="hidden" name="<?php echo $itemQuantity40;?>" value="<?php echo $quant_produto40;?>">
    <input type="hidden" name="<?php echo $itemWeight40;?>" value="1000">
	
	<input type="hidden" name="<?php echo $itemId41; ?>" value="<?php echo $id_produto41;?>">
    <input type="hidden" name="<?php echo $itemDescription41; ?>" value="<?php echo $nome_produto41;?>">
    <input type="hidden" name="<?php echo $itemAmount41; ?>" value="<?php echo $valor_produto41;?>">
    <input type="hidden" name="<?php echo $itemQuantity41; ?>" value="<?php echo $quant_produto41;?>">
    <input type="hidden" name="<?php echo $itemWeight41; ?>" value="1000">

    <input type="hidden" name="<?php echo $itemId42;?>" value="<?php echo $id_produto42;?>">
    <input type="hidden" name="<?php echo $itemDescription42;?>" value="<?php echo $nome_produto42;?>">
    <input type="hidden" name="<?php echo $itemAmount42;?>" value="<?php echo $valor_produto42;?>">
    <input type="hidden" name="<?php echo $itemQuantity42;?>" value="<?php echo $quant_produto42;?>">
    <input type="hidden" name="<?php echo $itemWeight42;?>" value="1000">

    <input type="hidden" name="<?php echo $itemId43; ?>" value="<?php echo $id_produto43;?>">
    <input type="hidden" name="<?php echo $itemDescription43; ?>" value="<?php echo $nome_produto43;?>">
    <input type="hidden" name="<?php echo $itemAmount43;?>" value="<?php echo $valor_produto43;?>">
    <input type="hidden" name="<?php echo $itemQuantity43;?>" value="<?php echo $quant_produto43;?>">
    <input type="hidden" name="<?php echo $itemWeight43;?>" value="1000">
	
	<input type="hidden" name="<?php echo $itemId44; ?>" value="<?php echo $id_produto44;?>">
    <input type="hidden" name="<?php echo $itemDescription44; ?>" value="<?php echo $nome_produto44;?>">
    <input type="hidden" name="<?php echo $itemAmount44;?>" value="<?php echo $valor_produto44;?>">
    <input type="hidden" name="<?php echo $itemQuantity44;?>" value="<?php echo $quant_produto44;?>">
    <input type="hidden" name="<?php echo $itemWeight44;?>" value="1000">
	
	<input type="hidden" name="<?php echo $itemId45; ?>" value="<?php echo $id_produto45;?>">
    <input type="hidden" name="<?php echo $itemDescription45; ?>" value="<?php echo $nome_produto45;?>">
    <input type="hidden" name="<?php echo $itemAmount45; ?>" value="<?php echo $valor_produto45;?>">
    <input type="hidden" name="<?php echo $itemQuantity45; ?>" value="<?php echo $quant_produto45;?>">
    <input type="hidden" name="<?php echo $itemWeight45; ?>" value="1000">

    <input type="hidden" name="<?php echo $itemId46;?>" value="<?php echo $id_produto46;?>">
    <input type="hidden" name="<?php echo $itemDescription46;?>" value="<?php echo $nome_produto46;?>">
    <input type="hidden" name="<?php echo $itemAmount46;?>" value="<?php echo $valor_produto46;?>">
    <input type="hidden" name="<?php echo $itemQuantity46;?>" value="<?php echo $quant_produto46;?>">
    <input type="hidden" name="<?php echo $itemWeight46;?>" value="1000">

    <input type="hidden" name="<?php echo $itemId47; ?>" value="<?php echo $id_produto47;?>">
    <input type="hidden" name="<?php echo $itemDescription47; ?>" value="<?php echo $nome_produto47;?>">
    <input type="hidden" name="<?php echo $itemAmount47;?>" value="<?php echo $valor_produto47;?>">
    <input type="hidden" name="<?php echo $itemQuantity47;?>" value="<?php echo $quant_produto47;?>">
    <input type="hidden" name="<?php echo $itemWeight47;?>" value="1000">
	
	<input type="hidden" name="<?php echo $itemId48; ?>" value="<?php echo $id_produto48;?>">
    <input type="hidden" name="<?php echo $itemDescription48; ?>" value="<?php echo $nome_produto48;?>">
    <input type="hidden" name="<?php echo $itemAmount48;?>" value="<?php echo $valor_produto48;?>">
    <input type="hidden" name="<?php echo $itemQuantity48;?>" value="<?php echo $quant_produto48;?>">
    <input type="hidden" name="<?php echo $itemWeight48;?>" value="1000">
	
    <input type="hidden" name="<?php echo $itemId49; ?>" value="<?php echo $id_produto49;?>">
    <input type="hidden" name="<?php echo $itemDescription49; ?>" value="<?php echo $nome_produto49;?>">
    <input type="hidden" name="<?php echo $itemAmount49; ?>" value="<?php echo $valor_produto49;?>">
    <input type="hidden" name="<?php echo $itemQuantity49; ?>" value="<?php echo $quant_produto49;?>">
    <input type="hidden" name="<?php echo $itemWeight49; ?>" value="1000">

    <input type="hidden" name="<?php echo $itemId50;?>" value="<?php echo $id_produto50;?>">
    <input type="hidden" name="<?php echo $itemDescription50;?>" value="<?php echo $nome_produto50;?>">
    <input type="hidden" name="<?php echo $itemAmount50;?>" value="<?php echo $valor_produto50;?>">
    <input type="hidden" name="<?php echo $itemQuantity50;?>" value="<?php echo $quant_produto50;?>">
    <input type="hidden" name="<?php echo $itemWeight50;?>" value="1000">


	
	<table id="pAg">
	  <tr>
	  <td><a href="http://lorussomodas.com.br/1.php"><img src="_imagens/finalizar_compra.png"/></a></td>
	  <td id="eSpc"></td>
	   <td><input id="finalizar" name="submit"  type="image"
           src="_imagens/finalizar_compra.png"/>
       </td>
	  </tr>
	</table>
</form>

</section>
	
<footer id="rodape">  
 	<p id="empresa">Lo Russo Modas   CNPJ: 03071953000139<br/>
Rua Jerônimo Moravia 121 - São Paulo, SP - 03939075</br> 
E-mail: lorussomodas@ig.com.br</p>
	<p><img id="pagseguro" src="_imagens/banner_pagseguro.png"/></p>
	<p><img id="cartoes" src="_imagens/banner_cartoes.png"/></p>

</footer>

</div>
</body>

</html>